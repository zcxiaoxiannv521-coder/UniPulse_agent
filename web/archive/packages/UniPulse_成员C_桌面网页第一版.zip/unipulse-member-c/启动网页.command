#!/bin/zsh
set -eu
unipulse_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$unipulse_dir"

if [[ -x "$unipulse_dir/../../work/unipulse-venv/bin/python" ]]; then
  unipulse_python="$unipulse_dir/../../work/unipulse-venv/bin/python"
elif [[ -x "$unipulse_dir/.venv/bin/python" ]]; then
  unipulse_python="$unipulse_dir/.venv/bin/python"
else
  echo "首次启动：创建本地运行环境并安装依赖，需要联网。"
  if ! python3 -c 'import sys; assert sys.version_info >= (3, 11)' 2>/dev/null; then
    echo "请先安装 Python 3.11 或以上，再重新运行。"
    read -r 'unipulse_pause?按回车关闭'
    exit 1
  fi
  python3 -m venv .venv
  unipulse_python="$unipulse_dir/.venv/bin/python"
fi

if ! "$unipulse_python" -c 'import streamlit' 2>/dev/null; then
  "$unipulse_python" -m pip install -r requirements.txt
fi
if "$unipulse_python" - <<'PY'
from urllib.request import build_opener, ProxyHandler
try:
    with build_opener(ProxyHandler({})).open('http://127.0.0.1:8501/_stcore/health', timeout=2) as response:
        healthy = response.status == 200 and response.read().strip() == b'ok'
    raise SystemExit(0 if healthy else 1)
except Exception:
    raise SystemExit(1)
PY
then
  echo "8501 端口已有 Streamlit 网页服务，请直接打开 http://127.0.0.1:8501 。"
  echo "如果打开的不是 UniPulse，请检查之前启动的网页窗口；本脚本不会关闭其他服务。"
  read -r 'unipulse_pause?按回车关闭此提示窗口'
  exit 0
fi
echo "打开 http://127.0.0.1:8501 即可体验；在此窗口按 Control+C 停止。"
exec "$unipulse_python" -m streamlit run app.py --server.port 8501
