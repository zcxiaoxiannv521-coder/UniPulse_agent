import os
from pathlib import Path
import unittest
from unittest.mock import patch

from streamlit.testing.v1 import AppTest
from client import initial_workspace

APP = Path(__file__).resolve().parents[1] / 'app.py'


class PageTests(unittest.TestCase):
    def setUp(self):
        self.env = patch.dict(os.environ, {'UNIPULSE_API_BASE':'', 'UNIPULSE_LOCAL_TEST':'', 'UNIPULSE_API_TOKEN':''})
        self.env.start()
        self.addCleanup(self.env.stop)
        self.app = AppTest.from_file(str(APP), default_timeout=45).run()

    def backup(self):
        self.app.checkbox(key='fallback').check().run()
        self.assertFalse(self.app.exception)

    def click(self, label):
        next(b for b in self.app.button if b.label == label).click().run()
        self.assertFalse(self.app.exception)

    def test_default_is_single_read_only_board(self):
        self.assertFalse(self.app.exception)
        self.assertEqual(len(self.app.sidebar.radio), 0)
        self.assertEqual(len(self.app.chat_input), 0)
        self.assertEqual(len(self.app.text_input), 0)
        self.assertEqual(len(self.app.selectbox), 1)
        text = '\n'.join(m.value for m in self.app.markdown)
        self.assertIn('正式计划 v1', text)
        self.assertIn('复习第三章', text)
        self.assertIn('学习', text)

    def test_refresh_only_reads(self):
        before = self.app.session_state['demo_workspace']
        self.click('刷新看板')
        self.assertEqual(before, self.app.session_state['demo_workspace'])

    def test_progress_form_keeps_completed_task(self):
        self.backup()
        self.app.radio(key='progress_mode').set_value('报告明确进度').run()
        self.app.number_input(key='remain_t1').set_value(30)
        self.app.text_area[-1].set_value('第三章只完成一半，剩余30分钟。')
        self.click('保存明确反馈')
        state = self.app.session_state['demo_workspace']
        self.assertEqual(state['tasks'][0]['status'], 'partial')
        self.assertEqual(state['tasks'][0]['remaining_minutes'], 30)
        self.assertEqual(state['tasks'][2]['status'], 'done')
        self.assertEqual(state['plans'][0]['status'], 'needs_adjustment')

    def test_time_only_does_not_change_progress(self):
        self.backup()
        self.app.number_input(key='time_t1').set_value(30)
        self.click('保存学习时长')
        state = self.app.session_state['demo_workspace']
        self.assertEqual(state['tasks'][0]['actual_minutes'], 30)
        self.assertEqual(state['tasks'][0]['remaining_minutes'], 60)
        self.assertEqual(state['tasks'][0]['status'], 'todo')
        self.assertEqual(state['plans'][0]['status'], 'confirmed')

    def test_preview_evidence_cancel_then_confirm(self):
        self.backup()
        self.click('生成修改预览')
        state = self.app.session_state['demo_workspace']
        self.assertEqual(state['pending'][0]['capacity']['unplaced_minutes'], 80)
        self.assertEqual(state['pending'][0]['source_notice_ids'], ['n_change'])
        self.assertEqual(state['events'][0]['version'], 1)
        self.click('取消草稿')
        self.assertEqual(self.app.session_state['demo_workspace']['events'][0]['start_at'], '2026-12-04T14:00:00+08:00')
        self.click('生成修改预览')
        self.click('确认本次调整')
        state = self.app.session_state['demo_workspace']
        self.assertEqual(state['events'][0]['start_at'], '2026-12-02T14:00:00+08:00')
        self.assertEqual([r['status'] for r in state['reminders']], ['invalidated','pending'])
        self.assertEqual(state['plans'][0]['status'], 'needs_adjustment')
        text = '\n'.join(m.value for m in self.app.markdown)
        self.assertNotIn('正式计划 v2', text)
        self.assertIn('旧学习块', text)

    def test_goal_save(self):
        self.backup()
        next(w for w in self.app.text_input if w.label == '目标名称').set_value('我的机器学习复习目标')
        self.click('保存目标输入')
        self.assertEqual(self.app.session_state['demo_workspace']['goals'][0]['title'], '我的机器学习复习目标')

    def test_invalid_course_shows_error(self):
        self.backup()
        next(w for w in self.app.text_input if w.label == '课程名称').set_value('重复的课程')
        self.click('保存课程')
        self.assertTrue(any('已有课程' in e.value for e in self.app.error))
        self.assertEqual(len(self.app.session_state['demo_workspace']['classes']), 5)

    def test_chat_is_backup_and_does_not_claim_connected(self):
        self.backup()
        self.app.chat_input[0].set_value('帮我复习').run()
        self.assertFalse(self.app.exception)
        self.assertIn('未连接模型', self.app.session_state['chat_history'][-1]['content'])

    def test_untrusted_query_id_does_not_select_a_user(self):
        self.app.query_params['user_id'] = 'other-person'
        self.app.run()
        self.assertEqual(self.app.session_state['demo_workspace']['profile']['display_name'], '林同学')

    def test_api_mode_requires_session_credential_before_read(self):
        with patch.dict(os.environ, {'UNIPULSE_API_BASE':'http://127.0.0.1:8000'}), patch('client.ApiClient.snapshot') as read:
            app = AppTest.from_file(str(APP), default_timeout=45).run()
            self.assertFalse(app.exception)
            read.assert_not_called()
            self.assertEqual(app.text_input[0].label, '本次会话的测试访问凭据')

    def test_api_denial_does_not_show_demo_data(self):
        from client import ClientError
        with patch.dict(os.environ, {'UNIPULSE_API_BASE':'http://127.0.0.1:8000'}), patch('client.ApiClient.snapshot', side_effect=ClientError('没有权限访问这项数据。')):
            app = AppTest.from_file(str(APP), default_timeout=45)
            app.session_state['api_token'] = 'test-token'
            app.run()
            self.assertFalse(app.exception)
            self.assertTrue(app.error)
            self.assertNotIn('林同学', '\n'.join(m.value for m in app.markdown))


if __name__ == '__main__':
    unittest.main()
