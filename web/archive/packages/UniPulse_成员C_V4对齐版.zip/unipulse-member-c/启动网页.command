#!/bin/zsh
set -eu
unipulse_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$unipulse_dir"

if [[ -x "$unipulse_dir/../../work/unipulse-venv/bin/python" ]]; then
  unipulse_python="$unipulse_dir/../../work/unipulse-venv/bin/python"
elif [[ -x "$unipulse_dir/.venv/bin/python" ]]; then
  unipulse_python="$unipulse_dir/.venv/bin/python"
else
  echo "首次启动：创建本地运行环境并安装依赖，需要联网。"
  if ! python3 -c 'import sys; assert sys.version_info >= (3, 11)' 2>/dev/null; then
    echo "请先安装 Python 3.11 或以上，再重新运行。"
    read -r 'unipulse_pause?按回车关闭'
    exit 1
  fi
  python3 -m venv .venv
  unipulse_python="$unipulse_dir/.venv/bin/python"
fi

if ! "$unipulse_python" -c 'import streamlit' 2>/dev/null; then
  "$unipulse_python" -m pip install -r requirements.txt
fi
echo "打开 http://127.0.0.1:8501 即可体验；在此窗口按 Control+C 停止。"
exec "$unipulse_python" -m streamlit run app.py --server.port 8501
