"""成员 C：手机优先的单页看板。企微是主入口，网页表单仅供备用联调。"""
from datetime import datetime, time, timedelta
from html import escape
import json
import os

import streamlit as st

from client import ClientError, TZ, initial_workspace, make_client, parse_time
from view_model import agenda_for_day, plan_is_current

st.set_page_config(page_title="UniPulse · 我的校园计划", page_icon="🎓", layout="centered", initial_sidebar_state="collapsed")
st.markdown("""<style>
.block-container{max-width:980px;padding-top:1.5rem;padding-bottom:3rem}
h1,h2,h3{color:#164b35}
.school-head{display:flex;justify-content:space-between;gap:1rem;flex-wrap:wrap;border-bottom:1px solid #dbe6de;padding-bottom:1rem;margin-bottom:1rem}
.school-name{font:600 1.8rem 'Songti SC','STSong',serif;letter-spacing:.2rem;color:#006b48}
.school-en{font:12px Georgia,serif;color:#647b6c;margin-top:.4rem}.motto{font-family:'Songti SC',serif;color:#4b6658;font-size:14px}
.hero{background:#e7f1e9;border-left:4px solid #006b48;padding:1rem;border-radius:0 8px 8px 0;margin-bottom:1rem}
.hero strong{font-size:1.4rem;color:#164b35}.hero p{margin:.4rem 0 0}
.agenda-card{border:1px solid #dbe6de;border-left:4px solid #006b48;border-radius:7px;padding:.8rem 1rem;margin:.6rem 0;overflow-wrap:anywhere}
.agenda-card.review{border-left-color:#a96a16;background:#fff9ec}.agenda-card strong{font-size:16px}.agenda-card p{margin:.4rem 0 0;font-size:14px}
.agenda-card .meta{color:#4b6658;font-size:14px}
.week-wrap{overflow-x:auto}.week{width:100%;min-width:650px;border-collapse:collapse;font-size:14px}.week th,.week td{border:1px solid #dbe6de;padding:8px;text-align:left;vertical-align:top}.week th{background:#e7f1e9}.week small{display:block;font-size:13px;color:#4b6658}
@media(max-width:600px){.block-container{padding:1rem}.school-name{font-size:1.5rem}.motto{font-size:13px}}
</style>""", unsafe_allow_html=True)

STATUS = {"todo":"待开始","doing":"进行中","partial":"部分完成","done":"已完成","active":"执行中","needs_review":"待检查","needs_adjustment":"计划待调整","confirmed":"已确认","completed":"已完成","pending":"待处理","invalidated":"已失效","cancelled":"已取消","applied":"已应用"}


def human(value):
    return parse_time(value).astimezone(TZ).strftime("%m 月 %d 日 %H:%M")


def run_action(fn, *args):
    try:
        result = fn(*args)
        st.session_state["flash"] = result.get("message", "操作已完成。")
        st.rerun()
    except ClientError as exc:
        st.error(str(exc))


def reset_demo():
    st.session_state["demo_workspace"] = initial_workspace()
    st.session_state.pop("chat_history", None)
    st.session_state["flash"] = "已恢复 V4 脱敏示例。"
    st.rerun()


st.markdown('<div class="school-head"><div><div class="school-name">中山大学 · UniPulse</div><div class="school-en">SUN YAT-SEN UNIVERSITY · STUDENT PROJECT</div></div><div class="motto">博学 · 审问 · 慎思 · 明辨 · 笃行</div></div>', unsafe_allow_html=True)
st.caption("学生项目 · 非学校官方服务")

api_mode = bool(os.getenv("UNIPULSE_API_BASE", "").strip())
if api_mode and not st.session_state.get("api_token") and not (os.getenv("UNIPULSE_LOCAL_TEST") == "1" and os.getenv("UNIPULSE_API_TOKEN")):
    st.info("个人看板需要访问凭据。此处为后端联调入口，正式企微身份绑定尚未接通。")
    with st.form("access_form"):
        credential = st.text_input("本次会话的测试访问凭据", type="password")
        if st.form_submit_button("读取我的看板"):
            if credential.strip():
                st.session_state["api_token"] = credential.strip()
                st.rerun()
            st.error("请填写访问凭据。")
    st.stop()
try:
    client = make_client(st.session_state)
    workspace = client.snapshot()
except ClientError as exc:
    st.error(str(exc))
    if not api_mode:
        if st.button("恢复 V4 示例"):
            reset_demo()
    else:
        st.caption("没有改用演示数据。访问者身份及企微绑定必须由后端校验。")
        if st.button("清除本次会话凭据"):
            st.session_state.pop("api_token", None)
            st.rerun()
    st.stop()

now = parse_time(workspace["demo_now"]) if client.is_demo else datetime.now(TZ)
today, version = now.astimezone(TZ).date(), workspace["version"]
events = {e["id"]: e for e in workspace["events"]}
notices = {n["id"]: n for n in workspace["notices"]}
tasks = workspace["tasks"]
goal = workspace["goals"][0] if workspace["goals"] else None
plans = workspace["plans"]
pending = [a for a in workspace["pending"] if a["status"] == "pending"]
if client.is_demo:
    st.caption(f"脱敏网页演示 · 示例时间 {human(workspace['demo_now'])} · 未连接企微、模型或完整排程器")
else:
    st.caption("共享后端模式 · 数据与执行结果均从后端读取")
    if os.getenv("UNIPULSE_LOCAL_TEST") == "1":
        st.warning("当前是固定账号本机联调模式，不能用于多用户看板。")
if "flash" in st.session_state:
    st.success(st.session_state.pop("flash"))


def sources(source_ids):
    if not source_ids:
        st.caption("尚无关联通知证据，请回到主入口核对。")
    for source_id in source_ids:
        n = notices.get(source_id)
        if n:
            st.write(n["text"])
            published = human(n["published_at"]) if n.get("published_at") else "未知，不补猜"
            st.caption(f"{n['channel']} · 接收 {human(n['received_at'])} · 发布 {published} · {n['status']}")


def capacity_card(capacity):
    if not capacity:
        return
    st.write(f"剩余工作 **{capacity['required_minutes']} 分钟** · 可保留安排 **{capacity['kept_minutes']} 分钟** · 未排入 **{capacity['unplaced_minutes']} 分钟**")
    if capacity["unplaced_minutes"]:
        st.warning("仍有工作未排入：需要补充允许时段，或明确减少指定选做内容。范围未被自动删减。")
    st.caption(capacity["basis"])


def preview_card(action):
    with st.container(border=True):
        st.subheader("待确认调整 · 尚未生效")
        st.caption(f"确认编号 {action['id']} · 有效至 {human(action['expires_at'])}")
        # 差异与保留项由后端提供，不根据考试日期猜测其他业务的影响。
        for change in action["changes"]:
            st.write(f"**{change['label']}**")
            st.write("原安排："+change["before"])
            st.write("调整后："+change["after"])
        if action["preserved"]:
            st.write("保留："+"；".join(action["preserved"]))
        capacity_card(action.get("capacity"))
        with st.expander("核对这次调整的通知原文", key="source_"+action["id"]):
            sources(action["source_notice_ids"])
        stale = action["expected_version"] != version
        expired = datetime.now(TZ) >= parse_time(action["expires_at"])
        if stale or expired:
            st.warning("此预览已过时或过期，请回企微或备用入口重新生成。")
        st.caption("正常流程在企微确认；下面是网页备用确认。仅提交当前预览，不代表学习计划已重排或消息已送达。")
        if st.button("确认本次调整", key="apply_"+action["id"], disabled=stale or expired, type="primary"):
            run_action(client.confirm_action, action["id"])
        if st.button("取消草稿", key="cancel_"+action["id"]):
            run_action(client.cancel_action, action["id"])


period = "上午好" if now.hour < 12 else "下午好" if now.hour < 18 else "晚上好"
st.markdown(f'<div class="hero"><strong>{period}，{escape(workspace["profile"]["display_name"])}</strong><p>企微里交代，网页上查看。</p></div>', unsafe_allow_html=True)
st.caption("在企微私聊说“发一下计划表”，应打开当前个人看板。此版本尚未完成企微链接与身份绑定实测。")
if st.button("刷新看板"):
    st.rerun()
future_classes = sorted([c for c in workspace["classes"] if parse_time(c["start_at"]) >= now], key=lambda c: parse_time(c["start_at"]))
if future_classes:
    c = future_classes[0]
    st.info(f"下一节课：{human(c['start_at'])} · {c['course']} · {c['location']}")
else:
    st.info("暂无已录入的后续课程；空白不代表可自由安排。")
deadlines = [(e["start_at"], e["title"]) for e in workspace["events"] if parse_time(e["start_at"]) >= now]
deadlines += [(t["due_at"], t["title"]) for t in tasks if t.get("due_at") and t["status"] != "done" and parse_time(t["due_at"]) >= now]
if deadlines:
    due, title = min(deadlines, key=lambda pair: parse_time(pair[0]))
    st.write(f"**最近考试 / 截止：** {human(due)} · {title}")
if pending:
    st.warning(f"有 {len(pending)} 项待确认调整。下方正式安排尚未应用草稿。")
else:
    st.caption("当前没有待确认草稿。")

st.subheader("当前备考计划")
if not plans:
    st.info("尚无已确认计划，等待企微交代目标并确认；看板查询不会启动排程。")
for p in plans:
    if plan_is_current(workspace, p):
        st.write(f"**正式计划 v{p['version']} · 已确认**")
    else:
        st.warning(f"计划待调整 · 上次确认版本 v{p['version']}，不代表已生成有效新版。")
    st.caption(p["summary"])
    capacity_card(p.get("capacity"))
if goal:
    with st.expander("目标、每日上限与来源"):
        st.write(goal["title"])
        st.write(f"目标版本 {goal['version']} · 每天最多 {goal['daily_max_minutes']} 分钟")
        st.write(goal["scope"])
        st.write(goal["availability"])
        sources([events[goal["event_id"]]["source_notice_id"]] if goal["event_id"] in events and events[goal["event_id"]].get("source_notice_id") else [])

st.subheader("课程、考试与学习安排")
monday = today-timedelta(days=today.weekday())
days = [monday+timedelta(days=i) for i in range(7)]
agenda_days = [today+timedelta(days=i) for i in range(7)]
selected_day = st.selectbox("查看日期", agenda_days, format_func=lambda d: f"{d:%m 月 %d 日} · {['周一','周二','周三','周四','周五','周六','周日'][d.weekday()]}", key="agenda_day")
rows = agenda_for_day(workspace, selected_day)
if not rows:
    st.write("这天暂无已录入安排；未录入不代表有可用学习空档。")
for r in rows:
    end = "—"+parse_time(r["end_at"]).astimezone(TZ).strftime("%H:%M") if r["end_at"] else ""
    css = " review" if r["kind"] == "旧学习块" else ""
    st.markdown(f'<div class="agenda-card{css}"><div class="meta">{parse_time(r["start_at"]).astimezone(TZ):%H:%M}{end} · {escape(r["kind"])}</div><strong>{escape(r["title"])}</strong><p>{escape(r["detail"])} · {escape(r["status"])}</p></div>', unsafe_allow_html=True)
with st.expander("本周课表（横向查看）"):
    heads = "".join(f"<th>{d:%m.%d}<br>{['周一','周二','周三','周四','周五','周六','周日'][d.weekday()]}</th>" for d in days)
    cells = ""
    for day in days:
        courses = [r for r in agenda_for_day(workspace, day) if r["kind"] == "课程"]
        content = "<br>".join(f"{escape(r['title'])}<small>{parse_time(r['start_at']).astimezone(TZ):%H:%M} · {escape(r['detail'])}</small>" for r in courses) or "暂无录入"
        cells += "<td>"+content+"</td>"
    st.markdown('<div class="week-wrap"><table class="week"><thead><tr>'+heads+'</tr></thead><tbody><tr>'+cells+'</tr></tbody></table></div>', unsafe_allow_html=True)
with st.expander("查看未来七天全部安排"):
    for day in agenda_days:
        st.write(f"**{day:%m 月 %d 日}**")
        for r in agenda_for_day(workspace, day):
            st.write(f"{parse_time(r['start_at']).astimezone(TZ):%H:%M} · {r['kind']} · {r['title']} · {r['status']}")

st.subheader("待办与进度")
for task in tasks:
    with st.container(border=True):
        included = task.get("included", True)
        label = "必做" if task.get("required", True) else "选做"
        st.write(("✓ " if task["status"] == "done" else "□ ")+task["title"])
        st.caption(f"{STATUS.get(task['status'], task['status'])} · {label} · {'当前范围内' if included else '已明确移出当前范围'}")
        st.write(f"剩余估时 {task['remaining_minutes']} 分钟 · 累计学习 {task['actual_minutes']} 分钟")
        if task.get("feedback"):
            st.write(task["feedback"])
st.caption("学习时长不换算为完成比例或知识掌握程度。日常进度在企微反馈，网页备用入口见下方。")

for action in pending:
    preview_card(action)
with st.expander("通知来源与修改记录"):
    sources(list(notices))
    for item in reversed(workspace["activity"][-20:]):
        st.write(item["name"]+" · "+item["detail"])
        st.caption(item.get("kind", "后端记录")+" · "+human(item["at"]))
    st.write("提醒状态")
    for r in workspace["reminders"]:
        st.write(human(r["at"])+" · "+STATUS.get(r["status"], r["status"]))
    st.caption("入队、已失效与实际送达分别记录。本地演示不发消息。")

st.divider()
backup = st.checkbox("展开网页备用入口（企微不可用时使用）", key="fallback")
if backup:
    st.info("备用入口与看板使用同一个 client；正常使用从企微发起。本地演示不会自动解析通知或生成新计划。")
    with st.expander("通知原文与改期校对"):
        with st.form("notice_form"):
            text = st.text_area("通知原文", "机器学习期末考试提前至12月2日14:00，复习范围不变。")
            if st.form_submit_button("保留通知原文"):
                run_action(client.save_notice, text, version)
        if events and notices:
            with st.form("change_form"):
                event_id = st.selectbox("要修改的考试", list(events), format_func=lambda k: events[k]["title"])
                notice_id = st.selectbox("对应的通知证据", list(notices), index=list(notices).index("n_change") if "n_change" in notices else len(notices)-1, format_func=lambda k: notices[k]["text"][:45])
                day = st.date_input("校对后的新日期", value=today+timedelta(days=2))
                at = st.time_input("校对后的新时间", value=time(14))
                st.caption("人工校对仅用于备用联调；不会从原文自动推断时间或匹配对象。")
                if st.form_submit_button("生成修改预览", type="primary"):
                    run_action(client.preview_exam_change, event_id, datetime.combine(day, at, TZ).isoformat(), version, notice_id)
    with st.expander("目标与课表录入（初始化 / 联调）"):
        if goal and events:
            with st.form("goal_form"):
                title = st.text_input("目标名称", goal["title"])
                scope = st.text_area("复习范围", goal["scope"])
                daily = st.number_input("每日上限 / 分钟", 15, 480, goal["daily_max_minutes"], step=15)
                availability = st.text_area("允许时段与约束", goal["availability"])
                if st.form_submit_button("保存目标输入"):
                    run_action(client.save_goal, {"title":title,"scope":scope,"event_id":goal["event_id"],"daily_max_minutes":daily,"availability":availability}, version)
        with st.form("class_form"):
            course = st.text_input("课程名称")
            location = st.text_input("教室或地点")
            day = st.date_input("上课日期", today)
            start = st.time_input("开始时间", time(8))
            end = st.time_input("结束时间", time(9,35))
            if st.form_submit_button("保存课程"):
                run_action(client.add_class, {"course":course,"location":location,"start_at":datetime.combine(day,start,TZ).isoformat(),"end_at":datetime.combine(day,end,TZ).isoformat()}, version)
    with st.expander("明确进度反馈"):
        task_id = st.selectbox("选择任务", [t["id"] for t in tasks], format_func=lambda k: next(t["title"] for t in tasks if t["id"] == k), key="feedback_task") if tasks else None
        if task_id:
            current = next(t for t in tasks if t["id"] == task_id)
            mode = st.radio("这次反馈什么", ["只记录学习时长", "报告明确进度"], key="progress_mode")
            if mode == "只记录学习时长":
                with st.form("time_"+task_id):
                    actual = st.number_input("累计实际学习 / 分钟（替换原累计值）", 0, 10080, current["actual_minutes"], key="time_"+task_id)
                    st.caption("只保存用时，不推断完成比例、不扣减剩余工作，也不触发重排。")
                    if st.form_submit_button("保存学习时长"):
                        run_action(client.record_time, task_id, actual, version)
            else:
                with st.form("progress_"+task_id):
                    status = st.selectbox("本次明确状态", ["partial","doing","done","todo"], format_func=lambda k:STATUS[k])
                    remaining = st.number_input("明确剩余估时 / 分钟（完成时记为 0）", 0, 10080, current["remaining_minutes"], key="remain_"+task_id)
                    actual = st.number_input("累计实际学习 / 分钟（替换原累计值）", 0, 10080, current["actual_minutes"], key="actual_"+task_id)
                    feedback = st.text_area("进度说明", current.get("feedback", ""))
                    if st.form_submit_button("保存明确反馈"):
                        run_action(client.record_progress, task_id, {"status":status,"remaining_minutes":remaining,"actual_minutes":actual,"feedback":feedback}, version)
    with st.expander("共享 Agent 的网页备用对话"):
        st.caption("消息发送给同一后端 Agent。本地模式未连接模型。")
        for m in st.session_state.get("chat_history", []):
            with st.chat_message(m["role"]):
                st.write(m["content"])
        message = st.chat_input("给共享 Agent 发消息")
        if message:
            try:
                result = client.chat(message)
                if not isinstance(result.get("reply"), str):
                    raise ClientError("后端未返回有效回复。")
                history = st.session_state.get("chat_history", [])
                st.session_state["chat_history"] = (history+[{"role":"user","content":message},{"role":"assistant","content":result["reply"]}])[-20:]
                st.rerun()
            except ClientError as exc:
                st.error(str(exc))

if client.is_demo:
    with st.expander("演示数据与恢复"):
        st.download_button("下载当前数据快照", json.dumps(workspace, ensure_ascii=False, indent=2), "unipulse-demo.json", "application/json")
        agreed = st.checkbox("清除本次演示操作，恢复初始样例")
        if st.button("恢复示例", disabled=not agreed):
            reset_demo()
st.caption("成员 C · V4 单页看板对齐版 · 仅本机访问不等于手机企微访问验收通过")
