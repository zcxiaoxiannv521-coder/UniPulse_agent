"""UniPulse 成员 C：网页与交互。运行：python -m streamlit run app.py"""
from datetime import date, datetime, time, timedelta
from html import escape
import json
import os

import streamlit as st

from client import ClientError, TZ, initial_workspace, make_client, parse_time

st.set_page_config(page_title="UniPulse · 中大校园助手", page_icon="🎓", layout="wide")
st.markdown("""<style>
.block-container{max-width:1320px;padding-top:2rem;padding-bottom:3rem}
h1,h2,h3{color:#164b35}h1{font-family:'Songti SC','STSong',serif}
[data-testid='stSidebar']{border-right:1px solid #dbe6de}
.school-head{display:flex;justify-content:space-between;align-items:center;gap:1rem;flex-wrap:wrap;border-bottom:1px solid #dbe6de;padding-bottom:1.2rem;margin-bottom:1.2rem}
.school-name{font:600 2rem 'Songti SC',serif;letter-spacing:.3rem;color:#006b48}
.school-en{font:12px Georgia,serif;letter-spacing:.12rem;color:#647b6c;margin-top:.4rem}
.motto{color:#647b6c;letter-spacing:.12rem;font-family:'Songti SC',serif}
.welcome{background:#e7f1e9;border-left:4px solid #006b48;padding:1.2rem;margin:.6rem 0 1.2rem;border-radius:0 8px 8px 0}
.welcome strong{font-size:1.5rem;color:#164b35}.welcome p{margin:.5rem 0 0;color:#647b6c}
.week{width:100%;border-collapse:separate;border-spacing:5px;table-layout:fixed}
.week th{padding:10px 3px;font-size:14px;color:#647b6c;font-weight:500}
.week td{vertical-align:top;background:#f2f6f3;border-radius:6px;height:78px;padding:5px}
.week .time{width:66px;font-size:13px;color:#647b6c;background:transparent}
.course{background:#e3eee6;border-radius:5px;padding:8px;font-size:14px;overflow-wrap:anywhere;color:#1c3429}
.course small{display:block;margin-top:5px;color:#647b6c;font-size:12px}
.today{color:#006b48!important;background:#e7f1e9;border-radius:7px}
@media(max-width:700px){.week{display:none}.desktop-week-note{display:none}.block-container{padding-left:1rem;padding-right:1rem}}
@media(min-width:701px){.mobile-day-hint{display:none}}
</style>""", unsafe_allow_html=True)


def human(value):
    return parse_time(value).astimezone(TZ).strftime("%m 月 %d 日 %H:%M")


def run_action(fn, *args, refresh=True):
    try:
        result = fn(*args)
        st.session_state["flash"] = result.get("message", "操作已完成。")
        if refresh:
            st.rerun()
        return result
    except ClientError as exc:
        st.error(str(exc))
        return None


try:
    client = make_client(st.session_state)
    workspace = client.snapshot()
except ClientError as exc:
    st.error(str(exc))
    st.info("未使用演示数据替代后端结果。可检查后端配置，或清除 UNIPULSE_API_BASE 后使用明确的演示模式。")
    st.stop()

version = workspace["version"]
now = parse_time(workspace["demo_now"]) if client.is_demo else datetime.now(TZ)
today = now.date()
current_goal = workspace["goals"][0] if workspace["goals"] else None
events = {x["id"]: x for x in workspace["events"]}
tasks = workspace["tasks"]
STATUS = {"todo": "待开始", "doing": "进行中", "partial": "部分完成", "done": "已完成", "active": "执行中", "needs_review": "待 Agent 检查", "confirmed": "已确认", "completed": "已完成", "pending": "待处理", "invalidated": "已失效", "cancelled": "已取消"}

with st.sidebar:
    st.title("UniPulse")
    st.caption("中大校园 · 智能相伴")
    page = st.radio("个人工作台", ["今日概览", "我的目标", "我的课表", "通知与修改预览", "任务与反馈", "校园助手", "操作记录与接口"], key="page")
    st.divider()
    st.write("博学 · 审问 · 慎思")
    st.write("明辨 · 笃行")
    st.caption("学生项目 · 非学校官方服务")
    if client.is_demo:
        st.caption("演示数据只保留在本次网页会话。浏览器刷新/重开可能重置，可下载快照留存。")
        st.download_button("下载当前数据快照", json.dumps(workspace, ensure_ascii=False, indent=2), "unipulse-demo.json", "application/json")
        with st.expander("恢复初始示例"):
            agreed = st.checkbox("我知道本次演示操作会被清除")
            if st.button("恢复示例", disabled=not agreed):
                st.session_state["demo_workspace"] = initial_workspace()
                st.session_state.pop("chat_history", None)
                st.session_state["flash"] = "已恢复初始示例。"
                st.rerun()

st.markdown('<div class="school-head"><div><div class="school-name">中山大学</div><div class="school-en">SUN YAT-SEN UNIVERSITY · UNIPULSE</div></div><div class="motto">博学 · 审问 · 慎思 · 明辨 · 笃行</div></div>', unsafe_allow_html=True)
if client.is_demo:
    st.caption(f"成员 C 可运行版 · 页面演示模式 · 示例日期 {today} · 未连接模型/企微/自动重规划")
else:
    st.caption("成员 C 可运行版 · 已配置后端模式 · 所有数据与执行结果由后端返回")
if "flash" in st.session_state:
    st.success(st.session_state.pop("flash"))


def goal_summary():
    if not current_goal:
        st.info("尚未建立目标，可到“我的目标”录入。")
        return
    st.subheader(current_goal["title"])
    event = events.get(current_goal["event_id"])
    st.write("考试：" + (human(event["start_at"]) if event else "尚未核对"))
    st.caption(f"目标版本 {current_goal['version']} · {STATUS.get(current_goal['status'], current_goal['status'])}")
    st.write("复习范围：" + current_goal["scope"])
    st.write(f"每天最多 {current_goal['daily_max_minutes']} 分钟")
    st.write("可用时间/约束：" + current_goal["availability"])


def week_view():
    monday = today - timedelta(days=today.weekday())
    days = [monday + timedelta(days=i) for i in range(7)]
    st.subheader("本周课表")
    st.caption(f"{days[0]} 至 {days[-1]} · 具体日期课程")
    future = sorted([c for c in workspace["classes"] if parse_time(c["start_at"]) >= now], key=lambda x: parse_time(x["start_at"]))
    if future:
        c = future[0]
        st.info(f"下一节：{human(c['start_at'])} · {c['course']} · {c['location']}")
    slots = [("1—2 节", 8), ("3—4 节", 10), ("5—6 节", 14), ("7—8 节", 16)]
    heads = '<th class="time">节次</th>' + "".join(f'<th class="{"today" if day == today else ""}">{["周一","周二","周三","周四","周五","周六","周日"][i]}<br>{day:%m.%d}</th>' for i, day in enumerate(days))
    rows = ""
    assigned = set()
    for label, hour in slots:
        cells = f'<td class="time">{label}<br>{hour:02d}:00</td>'
        for day in days:
            matches = [c for c in workspace["classes"] if parse_time(c["start_at"]).astimezone(TZ).date() == day and hour <= parse_time(c["start_at"]).astimezone(TZ).hour < hour+2]
            content = ""
            for c in matches:
                assigned.add(c["id"])
                content += f'<div class="course">{escape(c["course"])}<small>{parse_time(c["start_at"]).astimezone(TZ):%H:%M}—{parse_time(c["end_at"]).astimezone(TZ):%H:%M}<br>{escape(c["location"])}</small></div>'
            cells += f"<td>{content}</td>"
        rows += f"<tr>{cells}</tr>"
    st.markdown(f'<table class="week"><thead><tr>{heads}</tr></thead><tbody>{rows}</tbody></table>', unsafe_allow_html=True)
    with st.expander("按天查看 / 查看所有时段", expanded=False):
        day = st.selectbox("选择日期", days, format_func=lambda x: f"{x:%m 月 %d 日} · {['周一','周二','周三','周四','周五','周六','周日'][x.weekday()]}")
        selected = sorted([c for c in workspace["classes"] if parse_time(c["start_at"]).astimezone(TZ).date() == day], key=lambda x: parse_time(x["start_at"]))
        if not selected:
            st.write("这天没有已录入的课程；未录入不代表学校没有安排。")
        for c in selected:
            st.write(f"{parse_time(c['start_at']).astimezone(TZ):%H:%M}—{parse_time(c['end_at']).astimezone(TZ):%H:%M}　{c['course']}　{c['location']}")
    extra = [c for c in workspace["classes"] if monday <= parse_time(c["start_at"]).astimezone(TZ).date() <= days[-1] and c["id"] not in assigned]
    if extra:
        st.caption("以下非标准时段课程不在上方四段网格中，也需留意：")
        for c in extra:
            st.write(human(c["start_at"]), c["course"], c["location"])


def preview_card(action):
    with st.container(border=True):
        st.subheader("确认前，看看关联影响")
        st.caption("操作编号 " + action["id"][:12])
        st.table([
            {"事项": "考试时间", "原安排": human(action["old"]), "修改后": human(action["new"])},
            {"事项": "考前一天提醒", "原安排": human((parse_time(action['old'])-timedelta(days=1)).isoformat()), "修改后": human(action["remind_at"])},
            {"事项": "固定课程与已完成任务", "原安排": "保留", "修改后": "保持不变"},
            {"事项": "未完成的学习计划", "原安排": "已确认安排", "修改后": "待 Agent 重新检查，不假称已重排"}
        ])
        st.caption("此处展示的是后端/演示适配器返回的预览。确认后不代表真实消息已经送达。")
        col1, col2 = st.columns(2)
        if col1.button("确认并同步", key="apply_"+action["id"], type="primary"):
            run_action(client.confirm_action, action["id"])
        if col2.button("取消预览", key="cancel_"+action["id"]):
            run_action(client.cancel_action, action["id"])


if page == "今日概览":
    st.markdown(f'<div class="welcome"><strong>下午好，{escape(workspace["profile"]["display_name"])}</strong><p>围绕一个目标，让每一次安排变化都看得清楚。</p></div>', unsafe_allow_html=True)
    columns = st.columns(3)
    columns[0].metric("未完成任务", sum(t["status"] != "done" for t in tasks))
    columns[1].metric("明确剩余工作", f"{sum(t['remaining_minutes'] for t in tasks if t['status'] != 'done')} 分钟")
    columns[2].metric("待确认修改", sum(a["status"] == "pending" for a in workspace["pending"]))
    week_view()
    left, right = st.columns([1.2, 1])
    with left, st.container(border=True):
        goal_summary()
    with right, st.container(border=True):
        st.subheader("下一步行动")
        for t in tasks:
            st.write(("✓ " if t["status"] == "done" else "□ ") + t["title"])
            st.caption(f"{STATUS.get(t['status'], t['status'])} · 剩余估时 {t['remaining_minutes']} 分钟")
        st.caption("到“任务与反馈”报告明确进度；到“通知与修改预览”体验改期。")
    for action in workspace["pending"]:
        if action["status"] == "pending":
            preview_card(action)

elif page == "我的目标":
    st.header("我的目标")
    if not events:
        st.info("尚未核对考试日期，请先由后台录入考试；当前不能凭空生成目标截止。")
    else:
        with st.form("goal_form"):
            title = st.text_input("目标名称", value=current_goal["title"] if current_goal else "准备期末考试")
            event_ids = list(events)
            selected_event = current_goal["event_id"] if current_goal else event_ids[0]
            event_id = st.selectbox("关联的已核对考试", event_ids, index=event_ids.index(selected_event) if selected_event in event_ids else 0, format_func=lambda k: events[k]["title"]+" · "+human(events[k]["start_at"]))
            scope = st.text_area("复习范围", value=current_goal["scope"] if current_goal else "")
            daily = st.number_input("每天最多学习多少分钟", min_value=15, max_value=480, value=int(current_goal["daily_max_minutes"] if current_goal else 90), step=15)
            availability = st.text_area("可用时间与固定约束", value=current_goal["availability"] if current_goal else "")
            st.caption("保存的是目标输入，不等于已经完成 Agent 规划。")
            if st.form_submit_button("保存目标输入", type="primary"):
                run_action(client.save_goal, {"title": title, "event_id": event_id, "scope": scope, "daily_max_minutes": daily, "availability": availability}, version)
    st.divider()
    goal_summary()
    st.subheader("现有学习时间块")
    for b in workspace["study_blocks"]:
        t = next((t for t in tasks if t["id"] == b["task_id"]), None)
        st.write(f"{human(b['start_at'])}—{parse_time(b['end_at']).astimezone(TZ):%H:%M} · {t['title'] if t else '待核对任务'}")
        st.caption(STATUS.get(b["status"], b["status"]))

elif page == "我的课表":
    st.header("我的课表")
    week_view()
    st.divider()
    st.subheader("添加一节具体日期的课程")
    with st.form("class_form", clear_on_submit=False):
        course = st.text_input("课程名称")
        location = st.text_input("教室或地点")
        day = st.date_input("上课日期", value=today)
        start = st.time_input("开始时间", value=time(8, 0))
        end = st.time_input("结束时间", value=time(9, 35))
        st.caption("本版录入具体日期，不自动扩散到整个学期。")
        if st.form_submit_button("保存课程", type="primary"):
            payload = {"course": course, "location": location, "start_at": datetime.combine(day, start, TZ).isoformat(), "end_at": datetime.combine(day, end, TZ).isoformat()}
            run_action(client.add_class, payload, version)

elif page == "通知与修改预览":
    st.header("通知与修改预览")
    with st.form("notice_form"):
        notice = st.text_area("通知原文", "【示例改期通知】机器学习期末考试由12月4日14:00提前至12月2日14:00，地点A101不变。", height=130)
        if st.form_submit_button("保留通知原文"):
            run_action(client.save_notice, notice, version)
    st.caption("演示模式不会自动解析自由文本。下面由你校对时间，检验预览与确认体验。真实模式由后端负责解析和来源匹配。")
    if events:
        with st.form("change_form"):
            event_id = st.selectbox("要修改的考试", list(events), format_func=lambda k: events[k]["title"])
            new_date = st.date_input("校对后的新日期", value=today+timedelta(days=2))
            new_time = st.time_input("校对后的新时间", value=time(14, 0))
            if st.form_submit_button("生成修改预览", type="primary"):
                result = run_action(client.preview_exam_change, event_id, datetime.combine(new_date, new_time, TZ).isoformat(), version, refresh=False)
                if result:
                    st.session_state.pop("flash", None)
                    st.rerun()
    for a in workspace["pending"]:
        if a["status"] == "pending":
            preview_card(a)
    with st.expander("已保留的原文"):
        for n in workspace["notices"]:
            st.text(n["text"])
            st.caption(n["status"])
        if not workspace["notices"]:
            st.write("还没有保存原文。")

elif page == "任务与反馈":
    st.header("任务与反馈")
    st.info("累计学习时长、明确完成进度和剩余估时分别填写，不自动推断知识掌握程度。")
    if not tasks:
        st.write("尚无任务，等待 Agent 生成并经你确认。")
    else:
        with st.form("progress_form"):
            task_id = st.selectbox("选择任务", [t["id"] for t in tasks], format_func=lambda k: next(t["title"] for t in tasks if t["id"] == k))
            status = st.selectbox("本次明确状态", ["partial", "doing", "done", "todo"], format_func=lambda k: STATUS[k])
            remaining = st.number_input("剩余工作估计还需多少分钟（完成时将保存为 0）", 0, 10080, 45, step=5)
            actual = st.number_input("该任务累计实际学习分钟（替换原累计值，不重复相加）", 0, 10080, 45, step=5)
            feedback = st.text_area("进度说明", "第三章完成一半，剩余部分预计还需45分钟。")
            if st.form_submit_button("保存明确反馈", type="primary"):
                run_action(client.record_progress, task_id, {"status": status, "remaining_minutes": remaining, "actual_minutes": actual, "feedback": feedback}, version)
        st.table([{"任务": t["title"], "状态": STATUS.get(t["status"], t["status"]), "剩余估时/分钟": t["remaining_minutes"], "累计耗时/分钟": t["actual_minutes"]} for t in tasks])

elif page == "校园助手":
    st.header("校园助手")
    st.caption("这是网页入口；成员 A 接入后将与企微共用同一 Agent 和目标。")
    if client.is_demo:
        st.info("当前未调用模型，不会假装自动规划。你可以先测试消息输入与展示。")
    for message in st.session_state.get("chat_history", []):
        with st.chat_message(message["role"]):
            st.write(message["content"])
    message = st.chat_input("交代目标、查询安排，或报告新的变化")
    if message:
        try:
            result = client.chat(message)
            reply = result.get("reply")
            if not isinstance(reply, str):
                raise ClientError("后端未返回有效回复。")
            history = st.session_state.setdefault("chat_history", [])
            history.extend([{"role": "user", "content": message}, {"role": "assistant", "content": reply}])
            st.session_state["chat_history"] = history[-20:]
            st.rerun()
        except ClientError as exc:
            st.error(str(exc))

elif page == "操作记录与接口":
    st.header("操作记录与接口")
    st.caption("演示模式记录页面操作，不冒充 Agent 工具调用。后端模式应返回真实运行摘要。")
    for item in reversed(workspace["activity"][-30:]):
        with st.container(border=True):
            st.write(item["name"])
            st.caption(item.get("kind", "后端记录")+" · "+human(item["at"]))
            st.write(item["detail"])
    if not workspace["activity"]:
        st.write("还没有页面操作记录。")
    st.subheader("提醒队列")
    st.table([{"时间": human(r["at"]), "状态": STATUS.get(r["status"], r["status"])} for r in workspace["reminders"]])
    st.caption("待发送队列不表示已发出或已读；本成员 C 版本不会发送真实消息。")
    with st.expander("对接方式"):
        st.write("默认 DemoClient。设置 UNIPULSE_API_BASE 后使用 ApiClient；失败会显示错误，不静默变成演示成功。")
        st.code("UNIPULSE_API_BASE=http://127.0.0.1:8000\nUNIPULSE_API_TOKEN=仅用于本机联调的测试凭据", language="text")
        st.write("接口路径与响应格式见 API_CONTRACT.md。用户身份由后端会话/凭据确定，不从表单传入 user_id。")

st.divider()
st.caption("UniPulse · 成员 C 第一轮实现 · 学生项目，不是学校官方服务")
