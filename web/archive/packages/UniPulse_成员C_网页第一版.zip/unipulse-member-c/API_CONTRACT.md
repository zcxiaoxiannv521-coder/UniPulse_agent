# UniPulse 成员 C 对接草案 v0.1

这是供成员 A、B 讨论的接口协议，**当前没有对应后端服务实现**。前端已将所有请求集中到 `client.py` 的 ApiClient，方便统一修改；DemoClient 不代表这些接口上线。

## 通用约定

前缀 `/v1`。JSON 请求及响应，带时区的 ISO 8601 日期。每次写入使用 `expected_version`；这个第一版使用工作台整体版本，后续可扩展为对象依赖版本集合。

成功：

```json
{"ok": true, "data": {"message": "已保存", "version": 2}}
```

失败使用非 2xx 状态：401 未认证、403 无权限、409 版本变化、422 输入不合法、5xx 服务失败。前端不会把未满足成功协议的返回解释为成功。

后端必须验证：身份/对象所属、时间约束、依赖版本、幂等、确认有效期及提交事务。不能依赖前端校验。认证凭据由启动环境提供；正式用户身份必须通过真实会话/用户凭据确定，不接受模型或表单指定 user_id。

## 端点

| 方法与路径 | 请求 | data 返回 |
|---|---|---|
| GET /workspace | 无 | 下述完整工作台对象 |
| POST /goals | payload：title、event_id、scope、daily_max_minutes、availability；expected_version | message、version |
| POST /classes | payload：course、location、start_at、end_at；expected_version | message、version |
| POST /tasks/{id}/progress | payload：status、remaining_minutes、actual_minutes、feedback；expected_version | message、version |
| POST /notices | text、expected_version | message、version；后端可同时开始解析 |
| POST /previews | event_id、new_start、expected_version | 明确预览对象；不得在生成时提交修改 |
| POST /actions/{id}/confirm | 空对象；认证用户点击触发 | message、version |
| POST /actions/{id}/cancel | 空对象 | message |
| POST /agent/messages | message | reply、run_id（运行编号可为空） |

当前只有一个目标编辑表单，后端可更新当前目标或返回新目标。需与前端约定，不默认对所有目标应用同一约束。

## 工作台对象

字段与演示实例见 `fixtures/workspace.json`，其中 `demo_now` 仅演示模式使用。真实模式不要信任客户端提供的当前时间。

- version：整数。
- profile：display_name、timezone。当前页面以 Asia/Shanghai 展示。
- goals：id、title、event_id、scope、daily_max_minutes、availability、status、version。
- events：id、title、start_at、location、source、version。
- classes：id、course、start_at、end_at、location。
- tasks：id、goal_id、title、remaining_minutes、actual_minutes、status、version，可含 feedback。
- study_blocks：id、task_id、start_at、end_at、status。
- reminders：id、event_id、at、status。待发送不等于已送达。
- notices：id、text、status。
- pending：预览对象列表。
- activity：at、name、detail、kind。真实 Agent 运行可返回简短工具/状态摘要，不能返回内部思维链或敏感日志。

初版日期/地点/状态均明确，不伪造缺失信息。前端将来需支持缺失字段时，应同时扩展协议与空态展示。

## 预览对象

```json
{
  "id": "由后端生成",
  "event_id": "exam_ml",
  "expected_version": 1,
  "event_version": 1,
  "old": "2026-12-04T14:00:00+08:00",
  "new": "2026-12-02T14:00:00+08:00",
  "remind_at": "2026-12-01T14:00:00+08:00",
  "status": "pending",
  "expires_at": "由后端生成的有效期"
}
```

实际提醒策略由后端计算，例子仅为提前一天。当前 UI 的预览表适配一个考试及其一天前提醒；复杂策略应由后端返回完整 changes 数组后再扩展 UI，不能套用此表误报所有提醒。

确认端点必须绑定当前用户、预览编号和有效批准，不能因为模型说“已确认”就执行。后端工具白名单不暴露该批准入口给模型；真实环境的会话/CSRF/批准凭据应由 A/B 实现。客户端点击只表示用户交互，不能替代服务端授权。

## 当前联调边界

1. 改期后真实 Agent 的任务重排、不可行协商、计划版本属于 A/B；前端只显示后端返回的状态。
2. 本版先覆盖同步操作。异步 Agent 的轮询/事件流将在 A 提供 run 协议后接入，不能用假动画冒充工具执行。
3. 任一后端错误都明确显示；禁止自动改用演示成功。
4. 页面需重新读取工作台以看到写入结果；后端仍需保证事务、幂等与提交后查询。
