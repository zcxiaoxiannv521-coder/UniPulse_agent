import os
from pathlib import Path
import unittest
from unittest.mock import patch

from streamlit.testing.v1 import AppTest

APP = Path(__file__).resolve().parents[1] / "app.py"


class PageTests(unittest.TestCase):
    def setUp(self):
        self.env = patch.dict(os.environ, {"UNIPULSE_API_BASE": ""})
        self.env.start()
        self.addCleanup(self.env.stop)
        self.app = AppTest.from_file(str(APP), default_timeout=45).run()

    def page(self, label):
        self.app.sidebar.radio[0].set_value(label).run()
        self.assertFalse(self.app.exception)

    def click(self, label):
        next(b for b in self.app.button if b.label == label).click().run()
        self.assertFalse(self.app.exception)

    def test_all_pages_render(self):
        for label in self.app.sidebar.radio[0].options:
            with self.subTest(page=label):
                self.page(label)

    def test_progress_form_keeps_completed_task(self):
        self.page("任务与反馈")
        self.click("保存明确反馈")
        state = self.app.session_state["demo_workspace"]
        self.assertEqual(state["tasks"][0]["status"], "partial")
        self.assertEqual(state["tasks"][0]["remaining_minutes"], 45)
        self.assertEqual(state["tasks"][2]["status"], "done")

    def test_preview_cancel_then_confirm(self):
        self.page("通知与修改预览")
        self.click("保留通知原文")
        self.click("生成修改预览")
        self.click("取消预览")
        state = self.app.session_state["demo_workspace"]
        self.assertEqual(state["events"][0]["start_at"], "2026-12-04T14:00:00+08:00")
        self.click("生成修改预览")
        self.click("确认并同步")
        state = self.app.session_state["demo_workspace"]
        self.assertEqual(state["events"][0]["start_at"], "2026-12-02T14:00:00+08:00")
        self.assertEqual([r["status"] for r in state["reminders"]], ["invalidated", "pending"])

    def test_goal_save(self):
        self.page("我的目标")
        self.app.text_input[0].set_value("我的机器学习复习目标")
        self.click("保存目标输入")
        self.assertEqual(self.app.session_state["demo_workspace"]["goals"][0]["title"], "我的机器学习复习目标")

    def test_invalid_course_shows_error(self):
        self.page("我的课表")
        self.app.text_input[0].set_value("重复的课程")
        self.click("保存课程")
        self.assertTrue(any("已有课程" in e.value for e in self.app.error))
        self.assertEqual(len(self.app.session_state["demo_workspace"]["classes"]), 5)

    def test_chat_does_not_claim_agent_connected(self):
        self.page("校园助手")
        self.app.chat_input[0].set_value("帮我复习").run()
        self.assertFalse(self.app.exception)
        history = self.app.session_state["chat_history"]
        self.assertEqual(history[-2]["content"], "帮我复习")
        self.assertIn("未连接模型", history[-1]["content"])


if __name__ == "__main__":
    unittest.main()
